import React, { Component } from "react";
import styled, { css } from "styled-components";

function Untitled1(props) {
  return (
    <Container>
      <Image>
        <Image2>
          <Image3
            src={require("../assets/images/RECY_light_blue.png")}
          ></Image3>
        </Image2>
      </Image>
      <Image5Row>
        <Image5
          src={require("../assets/images/LOGO_DETRASH_BRANCO.png")}
        ></Image5>
        <Image4
          src={require("../assets/images/celo-logo-color-reverse-363.png")}
        ></Image4>
      </Image5Row>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  flex-direction: row;
  background-color: rgba(0,26,53,1);
  height: 100vh;
  width: 100vw;
`;

const Image = styled.div`
  display: flex;
  width: 100%;
  height: 370px;
  flex-direction: column;
  margin-top: 185px;
  background-image: url(${require("../assets/images/3.png")});
  background-size: cover;
`;

const Image2 = styled.div`
  display: flex;
  width: 360px;
  height: 100%;
  flex-direction: column;
  background-image: url(${require("../assets/images/4.png")});
  background-size: cover;
`;

const Image3 = styled.img`
  width: 360px;
  height: 100%;
  margin-top: 24px;
  object-fit: contain;
`;

const Image5 = styled.img`
  width: 100%;
  height: 116px;
  object-fit: contain;
`;

const Image4 = styled.img`
  width: 100%;
  height: 56px;
  margin-left: 106px;
  margin-top: 40px;
  object-fit: contain;
`;

const Image5Row = styled.div`
  height: 116px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 11px;
  margin-left: -350px;
  margin-top: 613px;
`;

export default Untitled1;
