import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialCheckboxWithLabel from "../components/MaterialCheckboxWithLabel";
import MaterialCheckboxWithLabel1 from "../components/MaterialCheckboxWithLabel1";
import MaterialCheckboxWithLabel2 from "../components/MaterialCheckboxWithLabel2";
import MaterialHelperTextBox from "../components/MaterialHelperTextBox";
import MaterialButtonShare from "../components/MaterialButtonShare";
import MaterialCheckboxWithLabel3 from "../components/MaterialCheckboxWithLabel3";

function Untitled9(props) {
  return (
    <Container>
      <ImageStack>
        <Image>
          <Image2>
            <MaterialCheckboxWithLabel
              style={{
                height: 40,
                width: 250,
                marginTop: 165,
                marginLeft: 11
              }}
            ></MaterialCheckboxWithLabel>
            <MaterialCheckboxWithLabel1
              style={{
                height: 40,
                width: 316,
                marginLeft: 11
              }}
            ></MaterialCheckboxWithLabel1>
            <MaterialCheckboxWithLabel2
              style={{
                height: 40,
                width: 304,
                marginLeft: 14
              }}
            ></MaterialCheckboxWithLabel2>
          </Image2>
        </Image>
        <MaterialHelperTextBox
          style={{
            height: 90,
            width: 292,
            position: "absolute",
            left: 16,
            top: 0
          }}
        ></MaterialHelperTextBox>
      </ImageStack>
      <MaterialButtonShare
        style={{
          height: 56,
          width: 56,
          marginLeft: -108,
          marginTop: 648
        }}
      ></MaterialButtonShare>
      <MaterialCheckboxWithLabel3
        style={{
          height: 40,
          width: 208,
          marginLeft: -173,
          marginTop: 584
        }}
      ></MaterialCheckboxWithLabel3>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  flex-direction: row;
  background-color: rgba(0,160,215,1);
  height: 100vh;
  width: 100vw;
`;

const Image = styled.div`
  display: flex;
  top: 45px;
  left: 0px;
  width: 360px;
  height: 370px;
  position: absolute;
  flex-direction: column;
  background-image: url(${require("../assets/images/3.png")});
  background-size: cover;
`;

const Image2 = styled.div`
  display: flex;
  width: 360px;
  height: 100%;
  flex-direction: column;
  background-image: url(${require("../assets/images/4.png")});
  background-size: cover;
`;

const ImageStack = styled.div`
  width: 360px;
  height: 415px;
  margin-top: 140px;
  position: relative;
`;

export default Untitled9;
