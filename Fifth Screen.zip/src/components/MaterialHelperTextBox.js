import React, { Component } from "react";
import styled, { css } from "styled-components";

function MaterialHelperTextBox(props) {
  return (
    <Container {...props}>
      <WhatIsYourName>What is your name?</WhatIsYourName>
      <InputStyle placeholder="Input"></InputStyle>
      <Helper>
        We won&#39;t use your data for anything outside the functioning of this
        app. :)
      </Helper>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  flex-direction: column;
`;

const WhatIsYourName = styled.span`
  font-family: Roboto;
  font-size: 18px;
  text-align: left;
  color: rgba(0,26,53,1);
  padding-top: 16px;
  font-style: normal;
  font-weight: 700;
`;

const InputStyle = styled.input`
  font-family: Roboto;
  border-bottom-width: 1px;
  border-color: #D9D5DC;
  color: rgba(255,255,255,1);
  font-size: 16px;
  align-self: stretch;
  line-height: 16px;
  padding-top: 8px;
  flex: 1 1 0%;
  padding-bottom: 8px;
  width: 375px;
  border: none;
  background: transparent;
  display: flex;
  flex-direction: column;
`;

const Helper = styled.span`
  font-family: Roboto;
  font-size: 10px;
  text-align: left;
  color: rgba(0,26,53,1);
  padding-top: 8px;
  font-style: normal;
  font-weight: 700;
`;

export default MaterialHelperTextBox;
