import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialMapView1 from "../components/MaterialMapView1";
import MaterialButtonPrimary from "../components/MaterialButtonPrimary";
import MaterialChipWithImage from "../components/MaterialChipWithImage";
import MaterialButtonPrimary1 from "../components/MaterialButtonPrimary1";
import Button from "../components/Button";
import EntypoIcon from "react-native-vector-icons/dist/Entypo";
import FeatherIcon from "react-native-vector-icons/dist/Feather";
import MaterialButtonShare1 from "../components/MaterialButtonShare1";
import MaterialButtonShare2 from "../components/MaterialButtonShare2";
import MaterialButtonShare3 from "../components/MaterialButtonShare3";

function Untitled7(props) {
  return (
    <Container>
      <MaterialMapView1StackStack>
        <MaterialMapView1Stack>
          <MaterialMapView1
            style={{
              width: 360,
              height: 370,
              position: "absolute",
              left: 0,
              top: 0
            }}
          ></MaterialMapView1>
          <Rect>
            <EllipseStack>
              <svg
                viewBox="0 0 85.8 85.8"
                style={{
                  top: 0,
                  left: 0,
                  width: 119,
                  height: 119,
                  position: "absolute"
                }}
              >
                <ellipse
                  stroke="rgba(230, 230, 230,1)"
                  strokeWidth={0}
                  fill="rgba(0,104,196,1)"
                  cx={43}
                  cy={43}
                  rx={43}
                  ry={43}
                ></ellipse>
              </svg>
              <ProfilePic>Profile {"\n"}Pic</ProfilePic>
            </EllipseStack>
            <UserName>User Name</UserName>
            <Rect2>
              <MaterialButtonPrimary
                style={{
                  height: 36,
                  width: 174,
                  marginTop: 39,
                  marginLeft: 44
                }}
              ></MaterialButtonPrimary>
              <MaterialChipWithImage
                style={{
                  width: 187,
                  height: 32,
                  marginTop: 17,
                  marginLeft: 25
                }}
                cRecyCUsdPrice="cRECY/cREAL Price"
              ></MaterialChipWithImage>
              <MaterialChipWithImage
                style={{
                  width: 187,
                  height: 32,
                  marginTop: 11,
                  marginLeft: 25
                }}
                cRecyCUsdPrice="cRECY/cUSD Price"
              ></MaterialChipWithImage>
              <MaterialButtonPrimary1
                style={{
                  height: 36,
                  width: 174,
                  marginTop: 52,
                  marginLeft: 44
                }}
              ></MaterialButtonPrimary1>
              <YourWasteStack>
                <YourWaste>Your waste performance</YourWaste>
                <Image2
                  src={require("../assets/images/77-turn-y-axis-upside-down.png")}
                ></Image2>
              </YourWasteStack>
            </Rect2>
          </Rect>
          <Image1
            src={require("../assets/images/LOGO_DETRASH_BRANCO.png")}
          ></Image1>
        </MaterialMapView1Stack>
        <Group1>
          <Button1Stack>
            <Button
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                height: 85,
                width: 350,
                backgroundColor: "rgba(0,26,53,1)"
              }}
            ></Button>
            <EntypoIcon
              name="chevron-with-circle-right"
              style={{
                top: 20,
                left: 272,
                position: "absolute",
                color: "rgba(0,160,215,1)",
                fontSize: 40
              }}
            ></EntypoIcon>
            <YouHave1>You have been rewarded so far with</YouHave1>
            <LoremIpsum1>5,000.00 cRECYs</LoremIpsum1>
          </Button1Stack>
        </Group1>
        <Group2>
          <Button2Stack>
            <Button
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                height: 85,
                width: 350,
                backgroundColor: "rgba(0,26,53,1)"
              }}
            ></Button>
            <LoremIpsum2>1,000.00 cRECYs</LoremIpsum2>
            <CRecyStakingPool1>cRECY Staking Pool</CRecyStakingPool1>
            <EntypoIcon
              name="chevron-with-circle-right"
              style={{
                top: 20,
                left: 272,
                position: "absolute",
                color: "rgba(0,160,215,1)",
                fontSize: 40
              }}
            ></EntypoIcon>
            <FeatherIcon
              name="droplet"
              style={{
                top: 8,
                left: 194,
                position: "absolute",
                color: "rgba(174,208,161,1)",
                fontSize: 69
              }}
            ></FeatherIcon>
            <CRecyStakingPool2>5% {"\n"}APR</CRecyStakingPool2>
          </Button2Stack>
        </Group2>
        <Group3>
          <MaterialButtonShare1
            style={{
              height: 75,
              width: 75,
              shadowRadius: 0,
              boxShadow: "3px 3px 0px  1px rgba(174,208,161,1) "
            }}
          ></MaterialButtonShare1>
          <MaterialButtonShare2
            style={{
              height: 75,
              width: 75,
              shadowRadius: 0,
              boxShadow: "3px 3px 0px  1px rgba(174,208,161,1) "
            }}
          ></MaterialButtonShare2>
          <MaterialButtonShare3
            style={{
              height: 75,
              width: 75,
              shadowRadius: 0,
              boxShadow: "3px 3px 0px  1px rgba(174,208,161,1) "
            }}
          ></MaterialButtonShare3>
        </Group3>
      </MaterialMapView1StackStack>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  flex-direction: row;
`;

const Rect = styled.div`
  top: 0px;
  left: 0px;
  width: 262px;
  height: 740px;
  position: absolute;
  background-color: rgba(230,230,230,0.52);
  flex-direction: column;
  display: flex;
`;

const ProfilePic = styled.span`
  font-family: Roboto;
  top: 43px;
  left: 33px;
  position: absolute;
  font-style: normal;
  font-weight: 700;
  color: rgba(241,241,241,1);
`;

const EllipseStack = styled.div`
  width: 119px;
  height: 119px;
  margin-top: 43px;
  margin-left: 76px;
  position: relative;
`;

const UserName = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 700;
  color: rgba(0,104,196,1);
  font-size: 18px;
  margin-top: 12px;
  margin-left: 90px;
`;

const Rect2 = styled.div`
  width: 262px;
  height: 521px;
  background-color: rgba(0,104,196,0.62);
  flex-direction: column;
  display: flex;
  margin-top: 23px;
`;

const YourWaste = styled.span`
  font-family: Roboto;
  top: 0px;
  left: 2px;
  position: absolute;
  font-style: normal;
  font-weight: 700;
  color: rgba(255,255,255,1);
  height: 27px;
  width: 191px;
  font-size: 16px;
`;

const Image2 = styled.img`
  top: 23px;
  left: 0px;
  width: 185px;
  height: 149px;
  position: absolute;
  object-fit: contain;
`;

const YourWasteStack = styled.div`
  width: 193px;
  height: 172px;
  margin-top: 11px;
  margin-left: 38px;
  position: relative;
`;

const Image1 = styled.img`
  top: 636px;
  left: 71px;
  width: 116px;
  height: 116px;
  position: absolute;
  object-fit: contain;
`;

const MaterialMapView1Stack = styled.div`
  top: 0px;
  left: 0px;
  width: 360px;
  height: 752px;
  position: absolute;
`;

const Group1 = styled.div`
  top: 410px;
  left: 5px;
  width: 350px;
  height: 85px;
  position: absolute;
  flex-direction: column;
  display: flex;
`;

const YouHave1 = styled.span`
  font-family: Roboto;
  top: 12px;
  left: 20px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: rgba(70,125,241,1);
`;

const LoremIpsum1 = styled.span`
  font-family: Roboto;
  top: 42px;
  left: 27px;
  position: absolute;
  font-style: normal;
  font-weight: 700;
  color: rgba(0,160,215,1);
  font-size: 18px;
`;

const Button1Stack = styled.div`
  width: 350px;
  height: 85px;
  position: relative;
`;

const Group2 = styled.div`
  top: 513px;
  left: 5px;
  width: 350px;
  height: 85px;
  position: absolute;
  flex-direction: column;
  display: flex;
`;

const LoremIpsum2 = styled.span`
  font-family: Roboto;
  top: 42px;
  left: 31px;
  position: absolute;
  font-style: normal;
  font-weight: 700;
  color: rgba(0,160,215,1);
  font-size: 18px;
`;

const CRecyStakingPool1 = styled.span`
  font-family: Roboto;
  top: 15px;
  left: 20px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: rgba(70,125,241,1);
`;

const CRecyStakingPool2 = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: rgba(174,208,161,1);
  text-align: center;
  flex: 1 1 0%;
  height: 35px;
  width: 69px;
  font-size: 12px;
  position: absolute;
  top: 35px;
  left: 194px;
  display: flex;
  flex-direction: column;
`;

const Button2Stack = styled.div`
  width: 350px;
  height: 85px;
  position: relative;
`;

const Group3 = styled.div`
  top: 622px;
  left: 20px;
  width: 321px;
  height: 75px;
  position: absolute;
  flex-direction: row;
  justify-content: space-between;
  display: flex;
`;

const MaterialMapView1StackStack = styled.div`
  width: 360px;
  height: 752px;
  position: relative;
`;

export default Untitled7;
