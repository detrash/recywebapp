import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialCommunityIconsIcon from "react-native-vector-icons/dist/MaterialCommunityIcons";

function MaterialButtonShare2(props) {
  return (
    <Container {...props}>
      <MaterialCommunityIconsIcon
        name="file-document-box-multiple-outline"
        style={{
          color: "#fff",
          fontSize: 47,
          alignSelf: "center"
        }}
      ></MaterialCommunityIconsIcon>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  background-color: rgba(119,178,94,1);
  align-items: center;
  justify-content: center;
  border-radius: 100px;
  min-width: 40px;
  min-height: 40px;
  flex-direction: column;
  box-shadow: 0px 2px 1.2px  0.2px #111 ;
`;

export default MaterialButtonShare2;
