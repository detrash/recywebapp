import React, { Component } from "react";
import styled, { css } from "styled-components";

function MaterialChipWithImage(props) {
  return (
    <Container {...props}>
      <LeftImage src={require("../assets/images/12.png")}></LeftImage>
      <CRecyCUsdPrice>
        {props.cRecyCUsdPrice || "cRECY/cUSD Price"}
      </CRecyCUsdPrice>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  background-color: rgb(230,230,230);
  border-radius: 50px;
  flex-direction: row;
`;

const LeftImage = styled.img`
  height: 32px;
  width: 100%;
  background-color: #CCC;
  border-radius: 16px;
`;

const CRecyCUsdPrice = styled.span`
  font-family: Roboto;
  font-size: 16px;
  color: rgba(0,26,53,1);
  padding-left: 8px;
  padding-right: 12px;
  font-weight: 700;
`;

export default MaterialChipWithImage;
