import React, { Component } from "react";
import styled, { css } from "styled-components";
import IoniconsIcon from "react-native-vector-icons/dist/Ionicons";
import MaterialButtonLight from "../components/MaterialButtonLight";

function Untitled4(props) {
  return (
    <Container>
      <ImageStack>
        <Image>
          <Image2>
            <IoniconsIcon
              name="md-globe"
              style={{
                color: "rgba(119,178,94,1)",
                fontSize: 200,
                height: 218,
                width: 163,
                marginTop: 55,
                marginLeft: 99
              }}
            ></IoniconsIcon>
            <LoremIpsum>Keeping the world clean. {"\n"}Together.</LoremIpsum>
          </Image2>
        </Image>
        <Image3 src={require("../assets/images/RECY_light_blue.png")}></Image3>
      </ImageStack>
      <MaterialButtonLight
        style={{
          height: 49,
          width: 286,
          marginLeft: -323,
          marginTop: 597
        }}
      ></MaterialButtonLight>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  flex-direction: row;
  background-color: rgba(0,26,53,1);
  height: 100vh;
  width: 100vw;
`;

const Image = styled.div`
  display: flex;
  top: 111px;
  left: 0px;
  width: 360px;
  height: 370px;
  position: absolute;
  flex-direction: column;
  background-image: url(${require("../assets/images/3.png")});
  background-size: cover;
`;

const Image2 = styled.div`
  display: flex;
  width: 360px;
  height: 100%;
  flex-direction: column;
  background-image: url(${require("../assets/images/4.png")});
  background-size: cover;
`;

const LoremIpsum = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 700;
  color: rgba(0,160,215,1);
  font-size: 26px;
  text-align: center;
  margin-top: 11px;
  margin-left: 33px;
`;

const Image3 = styled.img`
  top: 0px;
  left: 100px;
  width: 160px;
  height: 197px;
  position: absolute;
  object-fit: contain;
`;

const ImageStack = styled.div`
  width: 360px;
  height: 481px;
  margin-top: 74px;
  position: relative;
`;

export default Untitled4;
