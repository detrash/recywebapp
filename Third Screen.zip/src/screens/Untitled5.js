import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialStackedLabelTextbox1 from "../components/MaterialStackedLabelTextbox1";
import MaterialChipBasic from "../components/MaterialChipBasic";
import MaterialButtonSuccess from "../components/MaterialButtonSuccess";
import MaterialStackedLabelTextbox from "../components/MaterialStackedLabelTextbox";
import MaterialButtonShare from "../components/MaterialButtonShare";

function Untitled5(props) {
  return (
    <Container>
      <Image>
        <Image2>
          <MaterialStackedLabelTextbox1
            style={{
              height: 76,
              width: 290,
              marginTop: 3,
              marginLeft: 32
            }}
          ></MaterialStackedLabelTextbox1>
          <MaterialChipBasic
            style={{
              width: 263,
              height: 32,
              marginTop: 24,
              marginLeft: 46
            }}
          ></MaterialChipBasic>
          <Or2Stack>
            <Or2>or</Or2>
            <MaterialButtonSuccess
              style={{
                height: 55,
                width: 241,
                position: "absolute",
                left: 0,
                top: 59
              }}
            ></MaterialButtonSuccess>
          </Or2Stack>
        </Image2>
      </Image>
      <MaterialStackedLabelTextbox
        style={{
          height: 73,
          width: 296,
          marginLeft: -334,
          marginTop: 81
        }}
      ></MaterialStackedLabelTextbox>
      <MaterialButtonShare
        style={{
          height: 56,
          width: 56,
          marginLeft: -70,
          marginTop: 648
        }}
      ></MaterialButtonShare>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  flex-direction: row;
  background-color: rgba(129,169,113,1);
  height: 100vh;
  width: 100vw;
`;

const Image = styled.div`
  display: flex;
  width: 100%;
  height: 370px;
  flex-direction: column;
  margin-top: 185px;
  background-image: url(${require("../assets/images/3.png")});
  background-size: cover;
`;

const Image2 = styled.div`
  display: flex;
  width: 360px;
  height: 100%;
  flex-direction: column;
  background-image: url(${require("../assets/images/4.png")});
  background-size: cover;
`;

const Or2 = styled.span`
  font-family: Roboto;
  top: 0px;
  left: 70px;
  position: absolute;
  font-style: normal;
  font-weight: 700;
  color: rgba(0,26,53,1);
  height: 60px;
  width: 91px;
  font-size: 32px;
  text-align: center;
`;

const Or2Stack = styled.div`
  width: 241px;
  height: 114px;
  margin-top: 84px;
  margin-left: 56px;
  position: relative;
`;

export default Untitled5;
