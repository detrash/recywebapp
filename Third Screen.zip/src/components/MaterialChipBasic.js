import React, { Component } from "react";
import styled, { css } from "styled-components";

function MaterialChipBasic(props) {
  return (
    <Container {...props}>
      <ChipText>Login with google button</ChipText>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: rgb(230,230,230);
  border-radius: 50px;
  padding-left: 12px;
  padding-right: 12px;
  flex-direction: column;
`;

const ChipText = styled.span`
  font-family: Roboto;
  font-size: 13px;
  color: rgba(0,0,0,0.87);
  font-weight: 700;
`;

export default MaterialChipBasic;
