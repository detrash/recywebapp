import React, { Component } from "react";
import styled, { css } from "styled-components";

function MaterialStackedLabelTextbox(props) {
  return (
    <Container {...props}>
      <InsertYourMobile>Register with your Mobile</InsertYourMobile>
      <InputStyle placeholder="Input"></InputStyle>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  border-bottom-width: 1px;
  border-color: #D9D5DC;
  background-color: transparent;
  font-size: 31px;
  flex-direction: column;
`;

const InsertYourMobile = styled.span`
  font-family: Roboto;
  font-size: 18px;
  text-align: left;
  color: rgba(0,26,53,1);
  opacity: 0.8;
  padding-top: 16px;
  font-style: normal;
  font-weight: 700;
`;

const InputStyle = styled.input`
  font-family: Roboto;
  color: #000;
  font-size: 16px;
  align-self: stretch;
  flex: 1 1 0%;
  line-height: 16px;
  padding-top: 8px;
  padding-bottom: 8px;
  border: none;
  background: transparent;
  display: flex;
  flex-direction: column;
`;

export default MaterialStackedLabelTextbox;
