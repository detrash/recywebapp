import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialCommunityIconsIcon from "react-native-vector-icons/dist/MaterialCommunityIcons";

function MaterialButtonShare(props) {
  return (
    <Container {...props}>
      <MaterialCommunityIconsIcon
        name="apple-keyboard-control"
        style={{
          color: "rgba(0,160,215,1)",
          fontSize: 47,
          alignSelf: "center",
          transform: "rotate(undefined)",
          margin: 0,
          padding: 8
        }}
      ></MaterialCommunityIconsIcon>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  background-color: rgba(0,26,53,1);
  align-items: center;
  justify-content: center;
  border-radius: 100px;
  min-width: 40px;
  min-height: 40px;
  flex-direction: column;
  box-shadow: 0px 2px 1.2px  0.2px #111 ;
`;

export default MaterialButtonShare;
