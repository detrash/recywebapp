import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialMapView1 from "../components/MaterialMapView1";
import Menu from "../components/Menu";
import Button from "../components/Button";
import EntypoIcon from "react-native-vector-icons/dist/Entypo";
import FeatherIcon from "react-native-vector-icons/dist/Feather";
import MaterialButtonShare1 from "../components/MaterialButtonShare1";
import MaterialButtonShare2 from "../components/MaterialButtonShare2";
import MaterialButtonShare3 from "../components/MaterialButtonShare3";

function Untitled6(props) {
  return (
    <>
      <MaterialMapView2Stack>
        <MaterialMapView1
          style={{
            width: 360,
            height: 370,
            position: "absolute",
            left: 0,
            top: 0
          }}
        ></MaterialMapView1>
        <MaterialMapView1
          style={{
            width: 360,
            height: 370,
            position: "absolute",
            left: 0,
            top: 0
          }}
        ></MaterialMapView1>
        <Menu
          style={{
            position: "absolute",
            top: 38,
            left: 15,
            height: 58,
            width: 61
          }}
        ></Menu>
        <Profile>Profile</Profile>
      </MaterialMapView2Stack>
      <Group2>
        <ButtonStack>
          <Button
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              height: 85,
              width: 350,
              backgroundColor: "rgba(0,26,53,1)"
            }}
          ></Button>
          <EntypoIcon
            name="chevron-with-circle-right"
            style={{
              top: 20,
              left: 272,
              position: "absolute",
              color: "rgba(0,160,215,1)",
              fontSize: 40
            }}
          ></EntypoIcon>
          <YouHave>You have been rewarded so far with</YouHave>
          <LoremIpsum>5,000.00 cRECYs</LoremIpsum>
        </ButtonStack>
      </Group2>
      <Group3>
        <Button2Stack>
          <Button
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              height: 85,
              width: 350,
              backgroundColor: "rgba(0,26,53,1)"
            }}
          ></Button>
          <LoremIpsum1>1,000.00 cRECYs</LoremIpsum1>
          <CRecyStakingPool>cRECY Staking Pool</CRecyStakingPool>
          <EntypoIcon
            name="chevron-with-circle-right"
            style={{
              top: 20,
              left: 272,
              position: "absolute",
              color: "rgba(0,160,215,1)",
              fontSize: 40
            }}
          ></EntypoIcon>
          <FeatherIcon
            name="droplet"
            style={{
              top: 8,
              left: 194,
              position: "absolute",
              color: "rgba(174,208,161,1)",
              fontSize: 69
            }}
          ></FeatherIcon>
          <CRecyStakingPool1>5% {"\n"}APR</CRecyStakingPool1>
        </Button2Stack>
      </Group3>
      <Group>
        <MaterialButtonShare1
          style={{
            height: 75,
            width: 75,
            shadowRadius: 0,
            boxShadow: "3px 3px 0px  1px rgba(174,208,161,1) "
          }}
        ></MaterialButtonShare1>
        <MaterialButtonShare2
          style={{
            height: 75,
            width: 75,
            shadowRadius: 0,
            boxShadow: "3px 3px 0px  1px rgba(174,208,161,1) "
          }}
        ></MaterialButtonShare2>
        <MaterialButtonShare3
          style={{
            height: 75,
            width: 75,
            shadowRadius: 0,
            boxShadow: "3px 3px 0px  1px rgba(174,208,161,1) "
          }}
        ></MaterialButtonShare3>
      </Group>
    </>
  );
}

const Profile = styled.span`
  font-family: Roboto;
  top: 58px;
  left: 25px;
  position: absolute;
  font-style: normal;
  font-weight: 700;
  color: rgba(241,241,241,1);
`;

const MaterialMapView2Stack = styled.div`
  width: 360px;
  height: 370px;
  position: relative;
`;

const Group2 = styled.div`
  width: 350px;
  height: 85px;
  flex-direction: column;
  display: flex;
  margin-top: 40px;
  margin-left: 5px;
`;

const YouHave = styled.span`
  font-family: Roboto;
  top: 12px;
  left: 20px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: rgba(70,125,241,1);
`;

const LoremIpsum = styled.span`
  font-family: Roboto;
  top: 42px;
  left: 27px;
  position: absolute;
  font-style: normal;
  font-weight: 700;
  color: rgba(0,160,215,1);
  font-size: 18px;
`;

const ButtonStack = styled.div`
  width: 350px;
  height: 85px;
  position: relative;
`;

const Group3 = styled.div`
  width: 350px;
  height: 85px;
  flex-direction: column;
  display: flex;
  margin-top: 18px;
  margin-left: 5px;
`;

const LoremIpsum1 = styled.span`
  font-family: Roboto;
  top: 42px;
  left: 31px;
  position: absolute;
  font-style: normal;
  font-weight: 700;
  color: rgba(0,160,215,1);
  font-size: 18px;
`;

const CRecyStakingPool = styled.span`
  font-family: Roboto;
  top: 15px;
  left: 20px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: rgba(70,125,241,1);
`;

const CRecyStakingPool1 = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: rgba(174,208,161,1);
  text-align: center;
  flex: 1 1 0%;
  height: 35px;
  width: 69px;
  font-size: 12px;
  position: absolute;
  top: 35px;
  left: 194px;
  display: flex;
  flex-direction: column;
`;

const Button2Stack = styled.div`
  width: 350px;
  height: 85px;
  position: relative;
`;

const Group = styled.div`
  width: 321px;
  height: 75px;
  flex-direction: row;
  justify-content: space-between;
  margin-top: 24px;
  margin-left: 20px;
  display: flex;
`;

export default Untitled6;
