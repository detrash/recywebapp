import React, { Component } from "react";
import styled, { css } from "styled-components";

function Menu(props) {
  return (
    <Container {...props}>
      <svg
        viewBox="0 0 60.7 57.66"
        style={{
          width: 61,
          height: 58
        }}
      >
        <ellipse
          stroke="rgba(230, 230, 230,1)"
          strokeWidth={0}
          fill="rgba(0,104,196,1)"
          cx={30}
          cy={29}
          rx={30}
          ry={29}
        ></ellipse>
      </svg>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  flex-direction: column;
`;

export default Menu;
