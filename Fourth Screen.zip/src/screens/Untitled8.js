import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialStackedLabelTextbox2 from "../components/MaterialStackedLabelTextbox2";
import MaterialButtonShare from "../components/MaterialButtonShare";

function Untitled8(props) {
  return (
    <Container>
      <Image>
        <Image2>
          <MaterialStackedLabelTextbox2
            style={{
              height: 60,
              width: 316,
              marginTop: 59,
              marginLeft: 31
            }}
          ></MaterialStackedLabelTextbox2>
        </Image2>
      </Image>
      <MaterialButtonShare
        style={{
          height: 56,
          width: 56,
          marginLeft: -108,
          marginTop: 648
        }}
      ></MaterialButtonShare>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  flex-direction: row;
  background-color: rgba(129,169,113,1);
  height: 100vh;
  width: 100vw;
`;

const Image = styled.div`
  display: flex;
  width: 100%;
  height: 370px;
  flex-direction: column;
  margin-top: 185px;
  background-image: url(${require("../assets/images/3.png")});
  background-size: cover;
`;

const Image2 = styled.div`
  display: flex;
  width: 360px;
  height: 100%;
  flex-direction: column;
  background-image: url(${require("../assets/images/4.png")});
  background-size: cover;
`;

export default Untitled8;
