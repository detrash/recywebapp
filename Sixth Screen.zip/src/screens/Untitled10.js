import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialSwitch from "../components/MaterialSwitch";
import MaterialButtonShare from "../components/MaterialButtonShare";

function Untitled10(props) {
  return (
    <Container>
      <Image>
        <Image2>
          <LoremIpsum>Allow GPS access while using the app.</LoremIpsum>
          <MaterialSwitch
            style={{
              width: 61,
              height: 54,
              marginTop: 20,
              marginLeft: 149
            }}
          ></MaterialSwitch>
        </Image2>
      </Image>
      <MaterialButtonShare
        style={{
          height: 56,
          width: 56,
          marginLeft: -108,
          marginTop: 648
        }}
      ></MaterialButtonShare>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  flex-direction: row;
  background-color: rgba(0,160,215,1);
  height: 100vh;
  width: 100vw;
`;

const Image = styled.div`
  display: flex;
  width: 100%;
  height: 370px;
  flex-direction: column;
  margin-top: 185px;
  background-image: url(${require("../assets/images/3.png")});
  background-size: cover;
`;

const Image2 = styled.div`
  display: flex;
  width: 360px;
  height: 100%;
  flex-direction: column;
  background-image: url(${require("../assets/images/4.png")});
  background-size: cover;
`;

const LoremIpsum = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  font-size: 18px;
  margin-top: 116px;
  margin-left: 29px;
`;

export default Untitled10;
